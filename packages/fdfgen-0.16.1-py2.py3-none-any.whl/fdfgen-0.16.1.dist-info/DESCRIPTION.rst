Python port of the PHP forge_fdf library for creating FDF files


