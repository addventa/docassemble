"""Auto-generated file, do not edit by hand. 351 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_351 = [NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{3})', format='\\1 \\2 \\3', leading_digits_pattern=['2[12]']), NumberFormat(pattern='(\\d{2})(\\d{3})(\\d{2})(\\d{2})', format='\\1 \\2 \\3 \\4', leading_digits_pattern=['2[12]|9']), NumberFormat(pattern='(\\d{2})(\\d{3})(\\d{4})', format='\\1 \\2 \\3', leading_digits_pattern=['9'])]
