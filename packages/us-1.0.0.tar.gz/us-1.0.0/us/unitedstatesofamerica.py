name = 'United States of America'
abbr = 'US'

__all__ = ['name', 'abbr']
